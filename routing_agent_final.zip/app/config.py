import os

class Settings:
    # Google AI Studio માંથી મેળવેલી Gemini API Key અહીં નાખવી
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "your_gemini_api_key_here")

    LOCAL_MODEL_URL: str = os.getenv("LOCAL_MODEL_URL", "http://localhost:11434/api/generate")
    
settings = Settings()

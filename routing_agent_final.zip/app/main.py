from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import requests
from app.router import evaluate_complexity
from app.config import settings

app = FastAPI(title="Hybrid Token-Efficient Routing Agent")

class PromptRequest(BaseModel):
    prompt: str

def call_gemini_flash(prompt: str, reason: str):
    """Gemini 2.5 Flash API ને કોલ કરવા માટેનું ઓફિશિયલ ફંક્શન"""
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={settings.GEMINI_API_KEY}"
    
    headers = {
        "Content-Type": "application/json"
    }
    
    data = {
        "contents": [{
            "parts": [{"text": prompt}]
        }]
    }
    
    try:
        response = requests.post(url, headers=headers, json=data, timeout=10)
        if response.status_code == 200:
            res_json = response.json()
            # Gemini ના રિસ્પોન્સમાંથી ટેક્સ્ટ એક્સ્ટ્રેક્ટ કરવું
            output_text = res_json['candidates'][0]['content']['parts'][0]['text']
            return {
                "status": "success",
                "routed_to": "Gemini 2.5 Flash (High Accuracy)",
                "reason": reason,
                "response": output_text
            }
        else:
            raise HTTPException(status_code=500, detail=f"Gemini API Error: {response.text}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Cloud Connection Failed: {str(e)}")

@app.post("/generate")
async def generate_response(request: PromptRequest):
    route = evaluate_complexity(request.prompt)
    
    if route == "fireworks":  # અહીં ફ્લો મુજબ ક્લાઉડ ટાસ્ક Gemini પર જશે
        return call_gemini_flash(request.prompt, "Routed via Intelligence Logic (Complex Task)")
    else:
        # લોકલ મોડેલ (Ollama) ને કોલ કરવો
        data = {
            "model": "llama3",
            "prompt": request.prompt,
            "stream": False
        }
        try:
            response = requests.post(settings.LOCAL_MODEL_URL, json=data, timeout=5)
            if response.status_code == 200:
                res_json = response.json()
                local_output = res_json.get("response", "")
                
                if len(local_output.strip()) < 10 or "i cannot" in local_output.lower():
                    return call_gemini_flash(request.prompt, "Fallback: Local accuracy below threshold")
                    
                return {
                    "status": "success",
                    "routed_to": "Local Model (Token Efficient)",
                    "response": local_output
                }
            else:
                return call_gemini_flash(request.prompt, "Fallback: Local Server Error")
        except Exception as e:
            return call_gemini_flash(request.prompt, f"Fallback: Local Connection Failed ({str(e)})")

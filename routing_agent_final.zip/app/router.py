from app.config import settings

def count_tokens(text: str) -> int:
    """મોબાઇલ ફ્રેન્ડલી અંદાજિત ટોકન કાઉન્ટ (૧ શબ્દ ~ ૧.૩ ટોકન)"""
    words = text.split()
    return int(len(words) * 1.3)

def evaluate_complexity(prompt: str) -> str:
    # કોડિંગ અને જટિલ એનાલિસિસના કીવર્ડ્સ
    complex_keywords = ["code", "program", "algorithm", "solve", "math", "analyze", "optimize", "fix bug"]
    
    token_count = count_tokens(prompt)
    prompt_lower = prompt.lower()
    
    # નિયમ: ૧૫૦ ટોકનથી વધુ અથવા કીવર્ડ્સ મેચ થાય તો Fireworks ક્લાઉડ
    if token_count > 150 or any(keyword in prompt_lower for keyword in complex_keywords):
        return "fireworks"
    
    return "local"
